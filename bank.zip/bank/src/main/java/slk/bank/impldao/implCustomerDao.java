package slk.bank.impldao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import slk.bank.DBUtil.DBUtil;
import slk.bank.dao.customerDao;
import slk.bank.model.Customer;

@Repository
public class implCustomerDao implements customerDao{
	
	static List<Customer> list1= new ArrayList<>();	
	Connection connection;
	  public implCustomerDao() {
		  	connection = DBUtil.getConnection();
		System.out.println("connection "+connection);
	}
	  
	  public List<Customer> viewCustomer(){
			//List<Customer> customer = new ArrayList<Customer>();		
			System.out.println("Inside viewAll customer");
			try {
				
				System.out.println("Inside try");
				PreparedStatement stmt = connection.prepareStatement("select * from customer");
				ResultSet rs = stmt.executeQuery();
				while (rs.next())  {
					Customer cust=new Customer();
					System.out.println("Inside while");
					cust.setCustid(rs.getInt(1));
					cust.setAccno(rs.getInt(2));
					cust.setName(rs.getString(3));
					cust.setMobile(rs.getInt(4));
					cust.setAdhar(rs.getInt(5));
					cust.setDob(rs.getString(6));
					cust.setAddress(rs.getString(7));
					cust.setAcctype(rs.getString(8));
					cust.setEmail(rs.getString(9));
					cust.setPass(rs.getString(10));
					cust.setBrcode(rs.getInt(11));
					//cust.setAcctype(rs.getString(8));

					System.out.println("Inside while-2");
					list1.add(cust);
					System.out.println(list1);				
				}
				}catch(Exception e) {}
			return list1;
		}
	
		  

}
