package slk.bank.model;

public class Customer {

	
	int custid;
	int accno;
	String name;
	int mobile;
	int adhar;
	String dob;
	String address;
	String acctype;
	String email;
	String pass;
	int brcode;
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public int getAdhar() {
		return adhar;
	}
	public void setAdhar(int adhar) {
		this.adhar = adhar;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAcctype() {
		return acctype;
	}
	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public int getBrcode() {
		return brcode;
	}
	public void setBrcode(int brcode) {
		this.brcode = brcode;
	}
	@Override
	public String toString() {
		return "Customer [custid=" + custid + ", accno=" + accno + ", name=" + name + ", mobile=" + mobile + ", adhar="
				+ adhar + ", dob=" + dob + ", address=" + address + ", acctype=" + acctype + ", email=" + email
				+ ", pass=" + pass + ", brcode=" + brcode + "]";
	}
	public Customer(int custid, int accno, String name, int mobile, int adhar, String dob, String address,
			String acctype, String email, String pass, int brcode) {
		super();
		this.custid = custid;
		this.accno = accno;
		this.name = name;
		this.mobile = mobile;
		this.adhar = adhar;
		this.dob = dob;
		this.address = address;
		this.acctype = acctype;
		this.email = email;
		this.pass = pass;
		this.brcode = brcode;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
}
