package slk.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;



import slk.bank.dao.customerDao;
import slk.bank.model.Customer;


@RestController
public class controllerCustomer {

	
	@Autowired
	private customerDao custdao;
	
	@GetMapping("/Customer")
	 public List<Customer> getCustomers() {
		 return custdao.viewCustomer();
	 }
	 
	
	
	
}
